package coloring.org.jp.ktcc.full.custom_ui.fragment.listener;

/**
 * Created by nguyen on 10/19/2017.
 */

public interface SendToActivityListener {
    void onSelectPhoto(boolean isMultipleFile);
}
