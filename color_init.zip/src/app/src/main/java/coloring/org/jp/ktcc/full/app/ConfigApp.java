package coloring.org.jp.ktcc.full.app;

public class ConfigApp {
    public static final String PATH_FONT = "fonts/Roboto-Regular.ttf";
    public static final String PATH_FONT_MATISSE = "fonts/VNI-Matisse.ttf";
    public static final String PATH_FONT_NET_BUT = "fonts/VNI-Netbut.ttf";
    public static final String PATH_FONT_NHAT_BAN = "fonts/VNI-Nhatban.ttf";
    public static final String PATH_FONT_ONG_DO = "fonts/VNI-Ong do.ttf";
    public static final String PATH_FONT_KOINTAI = "fonts/kointai_seal.ttc";
    public static final String PATH_FONT_INSOUTAI = "fonts/insoutai_seal.TTF";

}
