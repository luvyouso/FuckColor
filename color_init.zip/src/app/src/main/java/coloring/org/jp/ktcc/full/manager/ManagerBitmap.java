package coloring.org.jp.ktcc.full.manager;

/**
 * Created by nguyen on 11/2/2017.
 */

public class ManagerBitmap {
}
