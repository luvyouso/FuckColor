package coloring.org.jp.ktcc.full.custom_ui;

/**
 * Created by nguyen on 11/28/2017.
 */

public interface ListenerFinger {
    public void focusLayer(Layer layer);
    public void unFocusLayer(Layer layer);
}
