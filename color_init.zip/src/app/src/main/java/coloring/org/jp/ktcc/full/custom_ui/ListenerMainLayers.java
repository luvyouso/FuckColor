package coloring.org.jp.ktcc.full.custom_ui;

/**
 * Created by nguyen on 11/28/2017.
 */

public interface ListenerMainLayers {
    public void selectBackground();
    public void selectLayer(int position);
    public void copySelectLayer();
}
